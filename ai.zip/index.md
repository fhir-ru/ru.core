# Home - v1

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://fhir.ru/ig/core/ImplementationGuide/ru.core | *Version*:1 |
| Active as of 2026-04-09 | *Computable Name*:RuCoreIG |

# RuCoreIG

Feel free to modify this index page with your own awesome content!

